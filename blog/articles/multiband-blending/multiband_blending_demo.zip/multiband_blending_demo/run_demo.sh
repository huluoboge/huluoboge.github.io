#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
if [[ ! -x ./multiband_blending_demo ]]; then
  echo "未找到 multiband_blending_demo，请先按照 README.md 编译。" >&2
  exit 1
fi
output="${1:-blended_from_run.png}"
match_color="${2:-0}"
./multiband_blending_demo apple.jpg orange.jpg mask.png "$output" 6 "$match_color"
printf 'output: %s\n' "$output"
