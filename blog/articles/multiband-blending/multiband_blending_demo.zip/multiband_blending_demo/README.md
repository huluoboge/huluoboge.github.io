# 多频段融合 demo

这个目录包含一个可以直接复现的 apple/orange 多频段融合示例。经典素材实际使用的是苹果和橙子，常见说法是 apple-orange demo；它不是苹果和梨。

## 文件说明

- `apple.jpg`：左侧输入图像
- `orange.jpg`：右侧输入图像
- `mask.png`：融合权值，左半部分为 255，右半部分为 0
- `blended.png`：6 层拉普拉斯金字塔、未做颜色匹配的输出
- `blended_match_color.png`：增加均值与标准差匹配后的输出
- `multiband_blending_demo.cpp`：C++17 / OpenCV 实现
- `run_demo.sh`：编译完成后运行示例的脚本
- `OPENCV_LICENSE.txt`：OpenCV 项目的 Apache 2.0 许可文本

输入图像尺寸为 512 × 512。mask 中的 255 表示使用苹果图像，0 表示使用橙子图像；程序会为 mask 建立高斯金字塔，使不同尺度上的过渡范围随尺度变化。

## 编译

压缩包不包含预编译的可执行文件。请在本机安装 OpenCV 4 开发环境后，在当前目录执行：

```bash
g++ -std=c++17 multiband_blending_demo.cpp -o multiband_blending_demo `pkg-config --cflags --libs opencv4`
```

## 运行

直接运行普通多频段融合：

```bash
./multiband_blending_demo apple.jpg orange.jpg mask.png blended_from_run.png 6 0
```

最后一个参数为颜色匹配开关。将它改为 `1` 可以启用代码中的均值与标准差匹配：

```bash
./multiband_blending_demo apple.jpg orange.jpg mask.png blended_from_run_match_color.png 6 1
```

也可以在完成编译后使用脚本：

```bash
./run_demo.sh
./run_demo.sh blended_from_run_match_color.png 1
```

## 素材来源与许可

`apple.jpg` 和 `orange.jpg` 来自 OpenCV 官方仓库的 `samples/data` 目录。OpenCV 项目采用 Apache License 2.0，压缩包中保留了完整许可文本。素材来源、项目许可和再次分发要求仍以 OpenCV 仓库中的最新说明为准。

## 实现说明

多通道图像中，互补权值需要保证每个通道都为 1。代码使用 `cv::Scalar::all(1.0)` 构造互补权值，避免仅有第一个通道为 1 导致输出颜色通道错误。
